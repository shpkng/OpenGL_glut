#include <vector>
#pragma once
class geometry
{
public:


};


struct point
{
	float x, y, z;
};
